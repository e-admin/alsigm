// variables de colores

var g_color1 = "#FFFFFF";
var g_color2 = "#000000";
var g_color3 = "#000000";
var g_color4 = "#EBEA87";
var g_color5 = "#CFCDCD";
