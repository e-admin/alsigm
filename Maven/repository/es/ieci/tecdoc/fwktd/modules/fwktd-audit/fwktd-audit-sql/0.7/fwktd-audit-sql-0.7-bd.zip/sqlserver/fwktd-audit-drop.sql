DROP TABLE audit_traza;

DROP TABLE audit_apps;

DROP TABLE AUDIT_TRAZA_SEQ;
