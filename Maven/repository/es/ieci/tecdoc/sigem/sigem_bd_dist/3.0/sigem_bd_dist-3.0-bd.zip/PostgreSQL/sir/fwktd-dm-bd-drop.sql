DROP TABLE documentos;
