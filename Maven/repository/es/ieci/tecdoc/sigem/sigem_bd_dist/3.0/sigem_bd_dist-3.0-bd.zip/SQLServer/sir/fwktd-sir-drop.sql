DROP TABLE sir_interesados;
DROP TABLE sir_anexos;
DROP TABLE sir_asientos_registrales;
DROP TABLE sir_contadores;
DROP TABLE sir_configuracion;

DROP TABLE sir_interesados_seq;
DROP TABLE sir_anexos_seq;
DROP TABLE sir_aregs_seq;
DROP TABLE sir_config_seq;
