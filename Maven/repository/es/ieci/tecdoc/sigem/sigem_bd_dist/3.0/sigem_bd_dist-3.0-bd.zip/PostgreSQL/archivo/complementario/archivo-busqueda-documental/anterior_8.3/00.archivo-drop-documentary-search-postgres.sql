DELETE FROM pg_ts_cfg WHERE ts_name = 'default_spanish';
DELETE FROM pg_ts_dict WHERE dict_name = 'es_ispell';