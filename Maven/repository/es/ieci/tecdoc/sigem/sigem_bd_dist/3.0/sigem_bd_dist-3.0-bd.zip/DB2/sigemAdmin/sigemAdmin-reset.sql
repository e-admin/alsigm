DROP VIEW sgm_adm_usuarios_v;
DROP TABLE sgm_adm_acciones;
DROP TABLE sgm_adm_perfiles;
DROP TABLE sgm_adm_entidades;
DROP TABLE sgm_adm_usuarios;