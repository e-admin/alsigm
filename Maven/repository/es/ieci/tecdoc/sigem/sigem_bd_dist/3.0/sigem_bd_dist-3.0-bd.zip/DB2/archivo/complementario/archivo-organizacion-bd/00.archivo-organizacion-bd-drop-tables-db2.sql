--  Eliminar las tablas del conector de organizaci�n

DROP TABLE AOESTRORG;
DROP TABLE AOUSR;
DROP TABLE AOUSRORGV;