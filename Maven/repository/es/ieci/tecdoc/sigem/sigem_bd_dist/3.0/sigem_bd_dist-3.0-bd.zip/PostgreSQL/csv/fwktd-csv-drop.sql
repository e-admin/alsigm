--
-- Tablas
--

DROP TABLE csv_documentos;
DROP TABLE csv_aplicaciones;


--
-- Secuencias
--

DROP SEQUENCE csv_apps_seq;
DROP SEQUENCE csv_docs_seq;
