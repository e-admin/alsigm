DELETE FROM iuserdepthdr;
DELETE FROM iusergenperms ;
DELETE FROM iusergrouphdr;
DELETE FROM iusergroupuser;
DELETE FROM iuseruserhdr;
DELETE FROM iuserusertype;
DELETE FROM scr_bookofic;
DELETE FROM scr_ofic;
DELETE FROM scr_userfilter;