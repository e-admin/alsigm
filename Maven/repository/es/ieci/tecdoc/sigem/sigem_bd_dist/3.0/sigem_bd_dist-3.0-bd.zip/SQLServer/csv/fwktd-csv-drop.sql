--
-- Tablas
--

DROP TABLE csv_documentos;
DROP TABLE csv_aplicaciones;


--
-- Secuencias
--

DROP TABLE csv_apps_seq;
DROP TABLE csv_docs_seq;
