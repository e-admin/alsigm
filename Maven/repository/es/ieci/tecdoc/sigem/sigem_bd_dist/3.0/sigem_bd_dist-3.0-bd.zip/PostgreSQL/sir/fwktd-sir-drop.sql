DROP TABLE sir_interesados;
DROP TABLE sir_anexos;
DROP TABLE sir_asientos_registrales;
DROP TABLE sir_contadores;
DROP TABLE sir_configuracion;

DROP SEQUENCE sir_interesados_seq;
DROP SEQUENCE sir_anexos_seq;
DROP SEQUENCE sir_aregs_seq;
DROP SEQUENCE sir_config_seq;
