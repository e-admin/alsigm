drop table scr_tramunit;
drop sequence scr_tramunit_id_seq;

drop table scr_entityreg;
drop sequence scr_entityreg_id_seq;

drop table scr_exregstate;
drop sequence scr_exregstate_id_seq;

drop table scr_exreg;
drop sequence scr_exreg_id_seq;

drop table scr_exreg_in;
drop sequence scr_exreg_in_id_seq;

drop table scr_provexreg;
drop table scr_citiesexreg;


drop table scr_attachment_sign_info;
drop sequence scr_attachment_sign_info_seq;

drop table scr_attachment;
drop sequence scr_attachment_seq;



drop TABLE scr_attachment_validity_type;

drop table scr_attachment_document_type;

drop table scr_repre;

