--Tabla para los datos adicionales de usuarios
CREATE TABLE iuserdata
(
  id NUMBER NOT NULL,
  cargo VARCHAR2(256),
  tfno_movil VARCHAR2(16),
  id_certificado VARCHAR2(256),
  email VARCHAR2(256),
  nombre VARCHAR2(256),
  apellidos VARCHAR2(256)
);

