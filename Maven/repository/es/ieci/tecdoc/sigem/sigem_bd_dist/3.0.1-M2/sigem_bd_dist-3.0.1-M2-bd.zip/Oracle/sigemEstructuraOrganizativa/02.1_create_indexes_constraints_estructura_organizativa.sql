ALTER TABLE iuserdata ADD CONSTRAINT pk_iuserdata PRIMARY KEY (id) ;
