ALTER TABLE ONLY sgl_obras_menores
    ADD CONSTRAINT pk_sgl_obras_menores PRIMARY KEY (id);
ALTER TABLE ONLY sgq_quejas
    ADD CONSTRAINT pk_sgq_quejas PRIMARY KEY (id);
ALTER TABLE ONLY sgs_subvenciones
    ADD CONSTRAINT pk_sgs_subvenciones PRIMARY KEY (id);
ALTER TABLE ONLY spac_tbl_010
    ADD CONSTRAINT pk_spac_tbl_010 PRIMARY KEY (id);
ALTER TABLE ONLY spac_tbl_011
    ADD CONSTRAINT pk_spac_tbl_011 PRIMARY KEY (id);
ALTER TABLE ONLY spac_tbl_012
    ADD CONSTRAINT pk_spac_tbl_012 PRIMARY KEY (id);
ALTER TABLE ONLY spac_tbl_013
    ADD CONSTRAINT pk_spac_tbl_013 PRIMARY KEY (id);
	
