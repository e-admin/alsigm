DROP TABLE audit_traza;

DROP TABLE audit_apps;

DROP SEQUENCE audit_traza_seq;