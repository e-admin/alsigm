--Tabla para los datos adicionales de usuarios
CREATE TABLE iuserdata
(
  id int NOT NULL,
  cargo varchar(256),
  tfno_movil varchar(16),
  id_certificado varchar(256),
  email varchar(256),
  nombre varchar(256),
  apellidos varchar(256)
);

